#Quiz App with FILE HANDLING




USERS_FILE = "users.txt"
QUESTIONS_FILE = "questions.txt"
ADMIN_ROLE = "admin"
USER_ROLE = "user"


def get_input(prompt):
  
    try:
        return raw_input(prompt)
    except NameError:
        return input(prompt)



def read_file_content(filename):
    try:
        
        f = open(filename, "r")
        content = f.read()
        f.close()
        
        return [item for item in content.split(";") if item.strip()]
    except IOError:
        return []

def write_line_to_file(filename, data_string):
    
    f = open(filename, "a")
    f.write(data_string + ";")
    f.close()

def rewrite_file(filename, data_list):
  
    f = open(filename, "w")
    content = ";".join(data_list)
    f.write(content + (";" if content else ""))
    f.close()



def get_users_map():
    raw_users = read_file_content(USERS_FILE)
    users = {}
    

    for user_data in raw_users:
        parts = user_data.strip().split("|")

        if len(parts) >= 10:
            username = parts[0]
            users[username] = {
                "password": parts[1],
                "role": parts[2],
                "college": parts[3],
                "enrollment": parts[4],
                "name": parts[5],
                "dob": parts[6],
                "branch": parts[7],
                "address": parts[8],
                "phone": parts[9],
                "email": parts[10] if len(parts) > 10 else ""
            }
    
    return users

def register_user(users):
    print("--- User Registration ---")
    while True:
        username = get_input("Enter username: ")
        if username in users:
            print("Username already exists. Try again.")
        else:
            break
            
    password = get_input("Enter password: ")
    print("--- Personal & College Details ---")
    college = get_input("College Name: ")
    enrollment = get_input("Enrollment No: ")
    name = get_input("Full Name: ")
    dob = get_input("DOB (DD-MM-YYYY): ")
    branch = get_input("Branch: ")
    address = get_input("Address: ")
    phone = get_input("Phone No: ")
    email = get_input("Email ID: ")


    new_user_data = "%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s" % (username, password, USER_ROLE, college, enrollment, name, dob, branch, address, phone, email)
    write_line_to_file(USERS_FILE, new_user_data)
    print("User registration successful!")

def register_admin(users):
    print("--- Admin Registration ---")
    while True:
        username = get_input("Enter Admin username: ")
        if username in users:
            print("Username already exists. Try again.")
        else:
            break
            
    password = get_input("Enter Admin password: ")



    new_admin_data = "%s|%s|%s|N/A|0|Admin Account|N/A|IT|N/A|0000000000|admin@quiz.com" % (username, password, ADMIN_ROLE)
    write_line_to_file(USERS_FILE, new_admin_data)
    print("Admin registration successful!")

def login_user(users, role):
    print("--- %s Login ---" % role.capitalize())
    username = get_input("Enter username: ")
    password = get_input("Enter password: ")

    if username in users:
        user_data = users[username]
        if user_data["password"] == password and user_data["role"] == role:
            print("Login successful! Welcome, %s." % username)
            return username
        else:
            print("Invalid password or role.")
    else:
        print("User not found.")
        
    return None

def forgot_password():
    print("--- Password Reset ---")
    username = get_input("Enter username: ")
    users = get_users_map()
    
    if username not in users:
        print("User not found.")
        return

    user_data = users[username]
    

    if user_data["role"] == ADMIN_ROLE:
        print("Admin account password cannot be reset via this method.")
        return

    print("Verify your details to reset password.")
    phone = get_input("Enter Phone No: ")
    email = get_input("Enter Email ID: ")

    if user_data.get("phone") == phone and user_data.get("email") == email:
        new_password = get_input("Enter new password: ")
        
        lines = read_file_content(USERS_FILE)
        new_lines = []
        

        for line in lines:
            parts = line.strip().split("|")
            if parts[0] == username:
                parts[1] = new_password 
                new_line = "|".join(parts)
                new_lines.append(new_line)
            else:
                new_lines.append(line)
        

        rewrite_file(USERS_FILE, new_lines)
        print("Password reset successful!")
        print("Please log in with your new password.")
    else:
        print("Phone or Email verification failed.")



def read_questions():
    raw_questions = read_file_content(QUESTIONS_FILE)
    questions = []
    for q_data in raw_questions:
        if q_data.strip():

            parts = q_data.strip().split("|")
            if len(parts) == 6:
                questions.append({
                    "question": parts[0],
                    "options": parts[1:5],
                    "correct": parts[5]
                })
    return questions

def admin_add_question():
    print("--- Add New Question ---")
    question = get_input("Enter Question: ")
    options = []
    for i in range(1, 5):
        options.append(get_input("Enter Option %d: " % i))
    
    while True:
        correct = get_input("Enter Correct Option Number (1-4): ")
        if correct.isdigit() and 1 <= int(correct) <= 4:
            break
        print("Invalid correct option number. Must be 1, 2, 3, or 4.")


    new_q_data = "%s|%s|%s|%s|%s|%s" % (question, options[0], options[1], options[2], options[3], correct)
    write_line_to_file(QUESTIONS_FILE, new_q_data)
    print("Question added successfully.")

def admin_edit_question():
    questions = read_questions()
    if not questions:
        print("No questions to edit.")
        return
        
    print("--- Edit Question ---")
    for i, q in enumerate(questions):
        print("%d. %s" % (i + 1, q["question"]))
    
    q_index_str = get_input("Enter question number to edit: ")
    
    if not (q_index_str.isdigit()):
        print("Invalid input.")
        return
        
    q_index = int(q_index_str)
    if not (1 <= q_index <= len(questions)):
        print("Invalid question number.")
        return
    
    index = q_index - 1
    q = questions[index]
    
    print("Editing Question %d:" % q_index)
    

    new_question = get_input("Enter new Question (Current: %s, Enter to keep): " % q["question"])
    if new_question:
        q["question"] = new_question
        

    for i in range(4):
        new_option = get_input("Enter new Option %d (Current: %s, Enter to keep): " % (i + 1, q["options"][i]))
        if new_option:
            q["options"][i] = new_option
    

    while True:
        new_correct = get_input("Enter new Correct Option Number (Current: %s, Enter to keep): " % q["correct"])
        if not new_correct:
            break
        if new_correct.isdigit() and 1 <= int(new_correct) <= 4:
            q["correct"] = new_correct
            break
        print("Invalid correct option number.")
        

    q_data_lines = []
    for q_item in questions:
        q_data_lines.append("%s|%s|%s|%s|%s|%s" % (
            q_item["question"], q_item["options"][0], q_item["options"][1], q_item["options"][2], q_item["options"][3], q_item["correct"]
        ))

    rewrite_file(QUESTIONS_FILE, q_data_lines)
    print("Question updated successfully.")

def admin_menu():
    while True:
        print("--- Admin Menu ---")
        print("1. Add Question")
        print("2. Edit Question")
        print("3. Back to Main Menu")
        choice = get_input("Enter choice: ")
        
        if choice == "1":
            admin_add_question()
        elif choice == "2":
            admin_edit_question()
        elif choice == "3":
            break
        else:
            print("Invalid choice.")


def start_quiz():
    questions = read_questions()
    if not questions:
        print("Quiz is not available. Please wait for the admin to add questions.")
        return
    
    print("--- Starting Quiz ---")
    score = 0
    total = len(questions)
    
    for i, q in enumerate(questions):
        print("Question %d of %d:" % (i + 1, total))
        print(q["question"])
        
        for j, option in enumerate(q["options"]):
            print("%d. %s" % (j + 1, option))
            
        while True:
            user_answer = get_input("Enter your choice (1-4): ")
            if user_answer.isdigit() and 1 <= int(user_answer) <= 4:
                break
            print("Invalid input. Enter a number between 1 and 4.")
            
        if user_answer == q["correct"]:
            print("Correct!")
            score += 1
        else:
            print("Incorrect. The correct option was %s." % q["correct"])
            
    print("--- Quiz Finished ---")
    print("Your final score is %d out of %d." % (score, total))



def main():
    print("Welcome to the Simple DSA Quiz App!")
    print("Please register a user account or an admin account to begin.")
    
    while True:
        print("--- Main Menu ---")
        print("1. User Login")
        print("2. User Registration")
        print("3. Admin Login")
        print("4. Admin Registration")
        print("5. Forgot Password (User Only)")
        print("6. Exit")
        
        choice = get_input("Enter choice: ")
        users = get_users_map()
        
        if choice == "1":
            username = login_user(users, USER_ROLE)
            if username:
                start_quiz()
        elif choice == "2":
            register_user(users)
        elif choice == "3":
            username = login_user(users, ADMIN_ROLE)
            if username:
                admin_menu()
        elif choice == "4":
            register_admin(users)
        elif choice == "5":
            forgot_password()
        elif choice == "6":
            print("Thank you for using the quiz app. Goodbye!")
            break
        else:
            print("Invalid choice. Try again.")

if __name__ == "__main__":
    main()



# quiz_question_creator.py

def add_question_to_file(filename):
    while True:
        question = input("Enter the question: ")
        option1 = input("Enter option 1: ")
        option2 = input("Enter option 2: ")
        option3 = input("Enter option 3: ")
        option4 = input("Enter option 4: ")
        correct_option = input("Enter correct option number (1-4): ")

        # Create the formatted line
        line = f"{question}|{option1}|{option2}|{option3}|{option4}|{correct_option}\n"

        # Append to the file
        with open(filename, "a", encoding="utf-8") as f:
            f.write(line)

        # Ask if user wants to add another question
        more = input("Add another question? (y/n): ").lower()
        if more != 'y':
            break


# Main execution
if __name__ == "__main__":
    filename = "questions.txt"
    add_question_to_file(filename)
    print(f"\nQuestions saved successfully to {filename} ✅")
def load_questions_from_file(filename):
    questions = []
    with open(filename, "r", encoding="utf-8") as f:
        for line in f:
            parts = line.strip().split("|")
            if len(parts) == 6:
                question_text = parts[0]
                options = parts[1:5]
                correct_option = int(parts[5])
                questions.append({
                    "question": question_text,
                    "options": options,
                    "answer": correct_option
                })
    return questions


    
